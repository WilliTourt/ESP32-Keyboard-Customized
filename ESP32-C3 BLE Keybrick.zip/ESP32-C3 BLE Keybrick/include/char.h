#ifndef __CHAR_H__
#define __CHAR_H__

#include <stdint.h>

extern const uint8_t OLED_ASCII6x8[][6];
extern const uint8_t OLED_ASCII8x16[][16];
extern const uint8_t Title[][16];
extern const uint8_t Bat[8];
extern const uint8_t BT[8];

// const uint8_t B306[];
// const ubyte code MH_cat[];
// const ubyte code surprised[];

#endif
