#ifndef __CHAR_H__
#define __CHAR_H__

#include <stdint.h>

extern const uint8_t OLED_ASCII6x8[][6];
extern const uint8_t OLED_ASCII8x16[][16];
// const uint8_t B306[];
// const ubyte code MH_cat[];
// const ubyte code surprised[];

#endif
