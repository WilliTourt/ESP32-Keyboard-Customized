#ifndef __SYS_H__
#define __SYS_H__

#include <Arduino.h>
#include <Preferences.h>
#include "key.h"
#include "battery.h"
#include "def.h"

typedef enum {
    MODE_NORMAL,
    MODE_TIMER_SET,
    MODE_METRONOME,
    MODE_KEY_CONFIG
} SystemMode;

struct SystemStatus {
    bool bleConnected;
    bool isCharging;
    unsigned long lastLedUpdate;
};

#define PRESET_COUNT 3

typedef struct {
    uint8_t keymap[5][8];
    uint8_t name[16];
    uint8_t keyDescription[5][16];
} KeyPreset;

extern KeyPreset presets[PRESET_COUNT];
extern uint8_t currentPreset;
extern uint8_t scrollPos;

extern SystemMode currentMode;
extern struct SystemStatus sysStatus;
extern bool changeName;

void SYS_ModeSwitch();
void SYS_KeyConfig();
void SYS_SavePreset();
void SYS_LoadPreset();
void SYS_ConfirmPreset(uint8_t preset);
void SYS_ApplyPreset(uint8_t presetIndex);
void SYS_StatusLEDCtrl();

#endif
